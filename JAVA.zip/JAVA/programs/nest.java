import java.util.Scanner;
class nest{
	public static void main(String args[])
	{
	int age;
	char gen;
	System.out.println("Enter your age :  ");
	Scanner en=new Scanner(System.in);
	age=en.nextInt();

	if(age>=18)
	{
	System.out.println("Your are eligible");
	System.out.println("Enter your gender :  ");
	gen=en.next().charAt(0);
	
	
	if(gen=='m' || gen=='M')
	{
	System.out.println("Room a");
	}
	
	else if(gen=='f' || gen=='F')
	{
	System.out.println("Room b");
	}
	else{
	System.out.println("Room c");
	}
	}
	else
	{
		System.out.println("Your are not eligible");
	}
}
}
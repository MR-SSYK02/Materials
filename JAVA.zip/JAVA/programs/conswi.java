
import java.util.Scanner;
public class conswi{
	public static void main (String args[])
	{
		char c;
		System.out.println("Enter the charecter : ");
		Scanner in = new Scanner(System.in);
		c= in.next().charAt(0);
	switch (c) {
      case 'a':
	  case 'e':
	  case 'i':
	  case 'o':
	  case 'u':
	  case 'A':
	  case 'E':
	  case 'I':
	  case 'O':
	  case 'U':
        System.out.println("vowel");
        break;
		default:
		 System.out.println(" not vowel");
        break;
    }
	}
}
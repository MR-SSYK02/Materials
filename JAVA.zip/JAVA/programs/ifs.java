import java.util.Scanner;
class ifs{
	public static void main(String args[])
	{
	int age;
	System.out.println("Enter your age :  ");
	Scanner en=new Scanner(System.in);
	age=en.nextInt();
	if(age>=18)
	{
	System.out.println("Your are eligible");
	}
	else
	{
		System.out.println("Your are not eligible");
	}
}
}
class variables{
	public static void main(String args[])
	{
		String name="senthil";
		int age=21;
		float percent=92.7f;
		char gender='m';
		boolean married=false;
		System.out.println("NAME 		  : "+name);
		System.out.println("AGE 		  : "+age);
		System.out.println("PERCENTAGE  	  : "+percent);
		System.out.println("GENDER   	  : "+gender);
		System.out.println("MARRIED  	  : "+married);		
	}
}
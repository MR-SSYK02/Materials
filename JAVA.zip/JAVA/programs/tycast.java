class tycast{
	public static void main(String args[])
	{
		int a=10;
		double b=a,d=52.10;
		int c=(int)d;
		System.out.println("int   :"+
		a);
		System.out.println("double   :"+
		b);
		System.out.println("double   :"+
		d);
		System.out.println("int   :"+
		c);
		
	}
}
class bit{
	public static void main(String args[])
	{
	int a=10,b=12;
	System.out.println(a>b&&b==a);
	System.out.println(a>b||b>a);
	}
}
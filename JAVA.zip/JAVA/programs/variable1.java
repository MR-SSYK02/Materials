class variable{
public static void main(String args[])
{
	String name="senthil";
	int age=20;
	float percent=92.9f;
	char gender='m';
	boolean married=false;
	System.out.println("NAME     ="+name);
	System.out.println("AGE      ="+age);
	System.out.println("PERCENT  ="+percent);
	System.out.println("GENDER   ="+gender);
	System.out.println("MARRIED  ="+married);
}
}
class unary{
	public static void main(String args[])
	{
	int a=10;
	System.out.println(a);
	a++;
	System.out.println(a);
	System.out.println(a++);
	System.out.println(a);
	System.out.println(++a);
	a--;
	System.out.println(a);
	System.out.println(a--);
	System.out.println(a);
	System.out.println(--a);
	}
}
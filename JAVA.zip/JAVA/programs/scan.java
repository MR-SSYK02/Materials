import java.util.Scanner;
class scan{
	public static void main(String args[])
	{
		Scanner in =new Scanner(System.in);
		int a,b,c;
		a=in.nextInt();
		b=in.nextInt();
		c=a+b;
		System.out.println(c);
	}
}
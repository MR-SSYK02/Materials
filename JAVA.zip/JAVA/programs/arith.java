class arith{
	public static void main(String args[])
	{
	int a=20,b=34;
	System.out.println("add : "+(a+b));
	System.out.println("sub : "+(a-b));
	System.out.println("mul : "+(a*b));
	System.out.println("div : "+(a/b));
	System.out.println("mod : "+(a%b));
	
	}
}